################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src/ctl_main.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/iris_280039c_board/oled_driver/oled_driver.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src/sinv_ui.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src/user_main.c 

C_DEPS += \
./user/ctl_main.d \
./user/oled_driver.d \
./user/sinv_ui.d \
./user/user_main.d 

OBJS += \
./user/ctl_main.obj \
./user/oled_driver.obj \
./user/sinv_ui.obj \
./user/user_main.obj 

OBJS__QUOTED += \
"user\ctl_main.obj" \
"user\oled_driver.obj" \
"user\sinv_ui.obj" \
"user\user_main.obj" 

C_DEPS__QUOTED += \
"user\ctl_main.d" \
"user\oled_driver.d" \
"user\sinv_ui.d" \
"user\user_main.d" 

C_SRCS__QUOTED += \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src/ctl_main.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/iris_280039c_board/oled_driver/oled_driver.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src/sinv_ui.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src/user_main.c" 


