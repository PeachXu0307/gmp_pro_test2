################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-1195503647: ../F280039_Iris_node.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"C:/ti/ccs1281/ccs/utils/sysconfig_1.21.0/sysconfig_cli.bat" --script "C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node/F280039_Iris_node.syscfg" -o "syscfg" -s "C:/Users/Peach/Documents/GitHub/gmp_pro_test3/.metadata/product.json" -s "C:/ti/c2000/C2000Ware_5_04_00_00/.metadata/sdk.json" -d "F28003x" -p "100PZ" -r "F28003x_100PZ" --compiler ccs
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/board.c: build-1195503647 ../F280039_Iris_node.syscfg
syscfg/board.h: build-1195503647
syscfg/board.cmd.genlibs: build-1195503647
syscfg/board.opt: build-1195503647
syscfg/board.json: build-1195503647
syscfg/pinmux.csv: build-1195503647
syscfg/epwm.dot: build-1195503647
syscfg/device.c: build-1195503647
syscfg/device.h: build-1195503647
syscfg/adc.dot: build-1195503647
syscfg/c2000ware_libraries.cmd.genlibs: build-1195503647
syscfg/c2000ware_libraries.opt: build-1195503647
syscfg/c2000ware_libraries.c: build-1195503647
syscfg/c2000ware_libraries.h: build-1195503647
syscfg/clocktree.h: build-1195503647
syscfg: build-1195503647

syscfg/%.obj: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O1 --fp_mode=relaxed --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3/csp/c28x_syscfg" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3/csp/c28x_syscfg/" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node/xplt" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/iris_280039c_board/oled_driver" --include_path="C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/common/include" --include_path="C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include" --include_path="C:/ti/c2000/C2000Ware_5_04_00_00/driverlib/f28003x/driverlib" --advice:performance=all --define=_FLASH -g --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="syscfg/$(basename $(<F)).d_raw" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node/Debug/syscfg" --obj_directory="syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

f28003x_codestartbranch.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/common/source/f28003x_codestartbranch.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O1 --fp_mode=relaxed --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3/csp/c28x_syscfg" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test3/csp/c28x_syscfg/" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/src" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node/xplt" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/iris_280039c_board/oled_driver" --include_path="C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/common/include" --include_path="C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include" --include_path="C:/ti/c2000/C2000Ware_5_04_00_00/driverlib/f28003x/driverlib" --advice:performance=all --define=_FLASH -g --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" --include_path="C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/suite/pgs_sinv_rc/project/f280039c_Iris_node/Debug/syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


