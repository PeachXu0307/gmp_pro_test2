# FIXED

device_support/f28003x_globalvariabledefs.obj: ../device_support/f28003x_globalvariabledefs.c
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_device.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/assert.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdarg.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdbool.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stddef.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_adc.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_aes.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_aes_ss.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_analogsubsys.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_bgcrc.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_cla.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_clb.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_clbxbar.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_cmpss.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_cputimer.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dac.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dcsm.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dma.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_ecap.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_epg.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_epwm.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_epwm_xbar.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_eqep.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_erad.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_flash.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_fsi.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_gpio.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_hic.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_i2c.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_input_xbar.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_memconfig.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_nmiintrupt.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_otp.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_output_xbar.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_piectrl.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_pievect.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_pmbus.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_sci.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_sdfm.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_spi.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_sysctrl.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_wwd.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_xbar.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_xint.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_tempsensorconv.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_can.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dcc.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_lin.h
device_support/f28003x_globalvariabledefs.obj: C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_mcan.h

../device_support/f28003x_globalvariabledefs.c:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_device.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/assert.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdarg.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdbool.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stddef.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_adc.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_aes.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_aes_ss.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_analogsubsys.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_bgcrc.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_cla.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_clb.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_clbxbar.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_cmpss.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_cputimer.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dac.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dcsm.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dma.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_ecap.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_epg.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_epwm.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_epwm_xbar.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_eqep.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_erad.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_flash.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_fsi.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_gpio.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_hic.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_i2c.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_input_xbar.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_memconfig.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_nmiintrupt.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_otp.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_output_xbar.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_piectrl.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_pievect.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_pmbus.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_sci.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_sdfm.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_spi.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_sysctrl.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_wwd.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_xbar.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_xint.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_tempsensorconv.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_can.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_dcc.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_lin.h:

C:/ti/c2000/C2000Ware_5_04_00_00/device_support/f28003x/headers/include/f28003x_mcan.h:

