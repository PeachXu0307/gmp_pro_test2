################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/std/src/crc16.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/advance/src/ctl_adv_fdrc.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/framework/src/ctl_cia402_callback_fn.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/framework/src/ctl_cia402_state_machine.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/interface/src/ctl_component_interface.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/continuous/src/ctl_continuous_pi.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/continuous/src/ctl_continuous_pid.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_biquad_filter.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_filter.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_lead_lag.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_pr.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_sg.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_sogi.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/basic/src/ctl_divider.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_sinv_protect.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_sinv_rc_core.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_sms_pq.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_spll_sogi.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/interface/src/ctl_if_pwm_h.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/protection/src/ctl_prot_pt100x.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/protection/src/ctl_protection.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_sinv_ref_gen.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/basic/src/ctl_slope_limiter.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_datalink.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_mem_presp.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_pil_core.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/pm/src/gmp_process_mgr.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/std/src/gmp_std_error_code.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/std/src/gmp_std_port.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_tunable.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/display/ht16k33.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/src/peripheral_driver.c \
C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/src/sysconfig_adapter.c 

C_DEPS += \
./gmp_src/crc16.d \
./gmp_src/ctl_adv_fdrc.d \
./gmp_src/ctl_cia402_callback_fn.d \
./gmp_src/ctl_cia402_state_machine.d \
./gmp_src/ctl_component_interface.d \
./gmp_src/ctl_continuous_pi.d \
./gmp_src/ctl_continuous_pid.d \
./gmp_src/ctl_discrete_biquad_filter.d \
./gmp_src/ctl_discrete_filter.d \
./gmp_src/ctl_discrete_lead_lag.d \
./gmp_src/ctl_discrete_pr.d \
./gmp_src/ctl_discrete_sg.d \
./gmp_src/ctl_discrete_sogi.d \
./gmp_src/ctl_divider.d \
./gmp_src/ctl_dp_sinv_protect.d \
./gmp_src/ctl_dp_sinv_rc_core.d \
./gmp_src/ctl_dp_sms_pq.d \
./gmp_src/ctl_dp_spll_sogi.d \
./gmp_src/ctl_if_pwm_h.d \
./gmp_src/ctl_prot_pt100x.d \
./gmp_src/ctl_protection.d \
./gmp_src/ctl_sinv_ref_gen.d \
./gmp_src/ctl_slope_limiter.d \
./gmp_src/gmp_datalink.d \
./gmp_src/gmp_mem_presp.d \
./gmp_src/gmp_pil_core.d \
./gmp_src/gmp_process_mgr.d \
./gmp_src/gmp_std_error_code.d \
./gmp_src/gmp_std_port.d \
./gmp_src/gmp_tunable.d \
./gmp_src/ht16k33.d \
./gmp_src/peripheral_driver.d \
./gmp_src/sysconfig_adapter.d 

OBJS += \
./gmp_src/crc16.obj \
./gmp_src/ctl_adv_fdrc.obj \
./gmp_src/ctl_cia402_callback_fn.obj \
./gmp_src/ctl_cia402_state_machine.obj \
./gmp_src/ctl_component_interface.obj \
./gmp_src/ctl_continuous_pi.obj \
./gmp_src/ctl_continuous_pid.obj \
./gmp_src/ctl_discrete_biquad_filter.obj \
./gmp_src/ctl_discrete_filter.obj \
./gmp_src/ctl_discrete_lead_lag.obj \
./gmp_src/ctl_discrete_pr.obj \
./gmp_src/ctl_discrete_sg.obj \
./gmp_src/ctl_discrete_sogi.obj \
./gmp_src/ctl_divider.obj \
./gmp_src/ctl_dp_sinv_protect.obj \
./gmp_src/ctl_dp_sinv_rc_core.obj \
./gmp_src/ctl_dp_sms_pq.obj \
./gmp_src/ctl_dp_spll_sogi.obj \
./gmp_src/ctl_if_pwm_h.obj \
./gmp_src/ctl_prot_pt100x.obj \
./gmp_src/ctl_protection.obj \
./gmp_src/ctl_sinv_ref_gen.obj \
./gmp_src/ctl_slope_limiter.obj \
./gmp_src/gmp_datalink.obj \
./gmp_src/gmp_mem_presp.obj \
./gmp_src/gmp_pil_core.obj \
./gmp_src/gmp_process_mgr.obj \
./gmp_src/gmp_std_error_code.obj \
./gmp_src/gmp_std_port.obj \
./gmp_src/gmp_tunable.obj \
./gmp_src/ht16k33.obj \
./gmp_src/peripheral_driver.obj \
./gmp_src/sysconfig_adapter.obj 

OBJS__QUOTED += \
"gmp_src\crc16.obj" \
"gmp_src\ctl_adv_fdrc.obj" \
"gmp_src\ctl_cia402_callback_fn.obj" \
"gmp_src\ctl_cia402_state_machine.obj" \
"gmp_src\ctl_component_interface.obj" \
"gmp_src\ctl_continuous_pi.obj" \
"gmp_src\ctl_continuous_pid.obj" \
"gmp_src\ctl_discrete_biquad_filter.obj" \
"gmp_src\ctl_discrete_filter.obj" \
"gmp_src\ctl_discrete_lead_lag.obj" \
"gmp_src\ctl_discrete_pr.obj" \
"gmp_src\ctl_discrete_sg.obj" \
"gmp_src\ctl_discrete_sogi.obj" \
"gmp_src\ctl_divider.obj" \
"gmp_src\ctl_dp_sinv_protect.obj" \
"gmp_src\ctl_dp_sinv_rc_core.obj" \
"gmp_src\ctl_dp_sms_pq.obj" \
"gmp_src\ctl_dp_spll_sogi.obj" \
"gmp_src\ctl_if_pwm_h.obj" \
"gmp_src\ctl_prot_pt100x.obj" \
"gmp_src\ctl_protection.obj" \
"gmp_src\ctl_sinv_ref_gen.obj" \
"gmp_src\ctl_slope_limiter.obj" \
"gmp_src\gmp_datalink.obj" \
"gmp_src\gmp_mem_presp.obj" \
"gmp_src\gmp_pil_core.obj" \
"gmp_src\gmp_process_mgr.obj" \
"gmp_src\gmp_std_error_code.obj" \
"gmp_src\gmp_std_port.obj" \
"gmp_src\gmp_tunable.obj" \
"gmp_src\ht16k33.obj" \
"gmp_src\peripheral_driver.obj" \
"gmp_src\sysconfig_adapter.obj" 

C_DEPS__QUOTED += \
"gmp_src\crc16.d" \
"gmp_src\ctl_adv_fdrc.d" \
"gmp_src\ctl_cia402_callback_fn.d" \
"gmp_src\ctl_cia402_state_machine.d" \
"gmp_src\ctl_component_interface.d" \
"gmp_src\ctl_continuous_pi.d" \
"gmp_src\ctl_continuous_pid.d" \
"gmp_src\ctl_discrete_biquad_filter.d" \
"gmp_src\ctl_discrete_filter.d" \
"gmp_src\ctl_discrete_lead_lag.d" \
"gmp_src\ctl_discrete_pr.d" \
"gmp_src\ctl_discrete_sg.d" \
"gmp_src\ctl_discrete_sogi.d" \
"gmp_src\ctl_divider.d" \
"gmp_src\ctl_dp_sinv_protect.d" \
"gmp_src\ctl_dp_sinv_rc_core.d" \
"gmp_src\ctl_dp_sms_pq.d" \
"gmp_src\ctl_dp_spll_sogi.d" \
"gmp_src\ctl_if_pwm_h.d" \
"gmp_src\ctl_prot_pt100x.d" \
"gmp_src\ctl_protection.d" \
"gmp_src\ctl_sinv_ref_gen.d" \
"gmp_src\ctl_slope_limiter.d" \
"gmp_src\gmp_datalink.d" \
"gmp_src\gmp_mem_presp.d" \
"gmp_src\gmp_pil_core.d" \
"gmp_src\gmp_process_mgr.d" \
"gmp_src\gmp_std_error_code.d" \
"gmp_src\gmp_std_port.d" \
"gmp_src\gmp_tunable.d" \
"gmp_src\ht16k33.d" \
"gmp_src\peripheral_driver.d" \
"gmp_src\sysconfig_adapter.d" 

C_SRCS__QUOTED += \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/std/src/crc16.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/advance/src/ctl_adv_fdrc.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/framework/src/ctl_cia402_callback_fn.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/framework/src/ctl_cia402_state_machine.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/interface/src/ctl_component_interface.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/continuous/src/ctl_continuous_pi.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/continuous/src/ctl_continuous_pid.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_biquad_filter.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_filter.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_lead_lag.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_pr.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_sg.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/discrete/src/ctl_discrete_sogi.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/basic/src/ctl_divider.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_sinv_protect.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_sinv_rc_core.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_sms_pq.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_dp_spll_sogi.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/interface/src/ctl_if_pwm_h.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/protection/src/ctl_prot_pt100x.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/protection/src/ctl_protection.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/digital_power/sinv/src/ctl_sinv_ref_gen.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/ctl/component/intrinsic/basic/src/ctl_slope_limiter.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_datalink.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_mem_presp.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_pil_core.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/pm/src/gmp_process_mgr.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/std/src/gmp_std_error_code.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/std/src/gmp_std_port.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/src/gmp_tunable.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/core/dev/display/ht16k33.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/src/peripheral_driver.c" \
"C:/Users/Peach/Documents/GitHub/gmp_pro_test2/csp/c28x_syscfg/src/sysconfig_adapter.c" 


