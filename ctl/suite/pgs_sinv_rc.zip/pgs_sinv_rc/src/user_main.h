//
// THIS IS A DEMO SOURCE CODE FOR GMP LIBRARY.
//
// User should add all declarations of user objects in this file.
//
// WARNING: This file must be kept in the include search path during compilation.
//

#include <core/dev/at_device.h>

#include <core/pm/function_scheduler.h>
#include <core/dev/display/ht16k33.h>

#ifndef _FILE_USER_MAIN_H_
#define _FILE_USER_MAIN_H_

#ifdef __cplusplus
extern "C"
{
#endif

//=================================================================================================
// global variables

extern cia402_sm_t cia402_sm;
extern iic_halt iic_bus;
extern ht16k33_dev_t ht16k33;

extern volatile uint16_t g_sinv_ui_raw_key;
extern volatile uint16_t g_sinv_ui_pressed_key;
extern volatile uint16_t g_sinv_ui_output_request;
extern volatile uint32_t g_sinv_ui_key8_count;
extern volatile uint16_t g_sinv_ui_last_iic_ec;

#ifndef SPECIFY_PC_TEST_ENV

#endif // SPECIFY_PC_TEST_ENV

//=================================================================================================
// global functions

//
// User should implement this 3 functions at least
//
void init(void);
void mainloop(void);
void setup_peripheral(void);

//
// For Controller projects user should implement the following functions
//
void ctl_init(void);
void ctl_mainloop(void);

gmp_task_status_t tsk_startup(gmp_task_t* tsk);
gmp_task_status_t tsk_sinv_ui_key(gmp_task_t* tsk);
gmp_task_status_t tsk_sinv_ui_display(gmp_task_t* tsk);
void sinv_ui_init(void);

#ifdef __cplusplus
}
#endif

#endif // _FILE_USER_MAIN_H_
